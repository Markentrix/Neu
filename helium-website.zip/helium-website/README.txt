Helium Café & Bar – Website Redesign
====================================
Start: index.html im Browser öffnen (Doppelklick). Kein Build nötig.

Dateien
- index.html   Seite mit allen Inhalten
- style.css    Design (Farben oben in :root, Braun + Karamell)
- script.js    Menü, Karten-Tabs, Reservierungsformular
- img/         Fotos (KI-generiert, bitte durch eigene Fotos ersetzen)
- einzeldatei-vorschau.html  Alles in einer Datei (Bilder eingebettet)

Hosting: Ordner-Inhalt per FTP/Netlify/GitHub Pages hochladen.
Noch zu ergänzen: Öffnungszeiten, Impressum/Datenschutz-Seiten,
Backend für das Reservierungsformular (aktuell öffnet es eine E-Mail).
